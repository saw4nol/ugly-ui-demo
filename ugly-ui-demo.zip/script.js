// Intentionally missing semicolon to break semi rule
const greeting = 'Hello from the ugly site'

function init(){
  console.log(greeting)
}

window.addEventListener('DOMContentLoaded', init)
